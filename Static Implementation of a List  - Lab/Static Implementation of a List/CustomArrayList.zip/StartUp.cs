﻿namespace Static_Implementation_of_a_List
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
